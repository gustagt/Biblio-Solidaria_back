class active_directory:
    IP = '10.101.22.3'
    DOMAIN = 'pmc'
    NAME = 'intra'
    
class   data_base:
    IP = '127.0.0.1'
    PORT = '3306'
    SCHEMA = 'biblio'
    USER = 'root'
    PASSWORD = '123456'
    
    